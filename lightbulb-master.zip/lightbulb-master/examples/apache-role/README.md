# apache-roles

This example demonstrates how roles are structured and used within a playbook. In communicating these concepts, this example is simply a refactoring of the `apache-basic-playbook` example into a role.
