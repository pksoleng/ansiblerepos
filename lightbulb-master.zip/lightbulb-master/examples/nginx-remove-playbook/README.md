# nginx-remove-playbook

This example demonstrates how to you would typically shutdown and remove an application service (nginx) from the hosts in a group called "web". The hosts are presumed to be running a Red Hat family linux.

This example was specifically developed as the solution to one of the extra credit assignments in `workshop/basic_playbook`.
