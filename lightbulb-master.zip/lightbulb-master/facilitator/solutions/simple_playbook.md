# Workshop: Simple Playbook

This assignment provides a quick introduction to playbook structure to give them a feel for how Ansible works, but in pratice is too simplistic to be useful.


## Tips

This workshop is a subset of the basic_playbook workshop students will do next.  Depending on the technical aptitude of students and time available you can opt to skip this workshop assignment. Everything here and a lot more will in the next workshop assignment.

## Solution

The solution to this workshop is `nginx-simple-playbook` under `examples/`.
